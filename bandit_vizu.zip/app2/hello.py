from bokeh.io import curdoc
from bokeh.layouts import column, row
from bokeh.models.widgets import TextInput, Button, Paragraph
from bokeh.plotting import figure
from bokeh.models import ColumnDataSource, Select, TextInput
from bokeh.core.properties import value
import numpy as np
import numpy as np
import gym
from gym import spaces
from gym.utils import seeding

import numpy as np
import gym
from gym import spaces
from gym.utils import seeding
from scipy.stats import *

band_rnorm = lambda a, b: norm(loc=a,scale=b).rvs(1)
band_dnorm = lambda a, b: (lambda x:norm(loc=a,scale=b).pdf(x),norm(loc=a,scale=b).mean(),norm(loc=a,scale=b).var())

band_rgamma = lambda a, b: gamma(a=a,scale=1/b).rvs(1)
band_dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(),gamma(a=a,scale=1/b).var())


class ArmedBanditsEnv(gym.Env):
    def __init__(self, reward_distributions, T = 100):
        self.T = T
        self.t = 0
        self.num_bandits = len(reward_distributions)
        self.action_space = spaces.Discrete(self.num_bandits)
        self.observation_space = spaces.Discrete(0)
        self.reward_distributions = reward_distributions
        self.model = ''
        self.attr = None
    def get_model(self, action):
        pass

    def step(self, action):
        pass

    def reset(self):
        self.t = 0
        pass

    def _seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]
    
class BernouilliBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'bernouilli'
    def get_model(self,action):
        return self.reward_distribution[action]

    def step(self, action):
        reward = 0
        if np.random.rand() < self.reward_distributions[action]:
            reward = 1
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GaussianMuBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gaussian_mu'
        self.attr = reward_distributions[0,1]
    def get_model(self, action):
        return band_dnorm(self.reward_distributions[action,0], self.attr)

    def step(self, action):
        reward = np.random.normal(self.reward_distributions[action,0], self.attr)
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GaussianSigBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gaussian_sig'
        self.attr = reward_distributions[0,0]
        
    def get_model(self, action):
        return band_dnorm(self.attr, self.reward_distributions[action,1])

    def step(self, action):
        reward = np.random.normal(self.attr, self.reward_distributions[action,1])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GaussianBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gaussian'

    def get_model(self, action):
        return band_dnorm(self.reward_distributions[action,0], self.reward_distributions[action,1])

    def step(self, action):
        reward = np.random.normal(self.reward_distributions[action,0], self.reward_distributions[action,1])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GammaKBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gamma_k'
        self.attr = reward_distributions[0,0]

    def get_model(self, action):
        return band_dgamma(self.attr, self.reward_distributions[action,1])

    def step(self, action):
        reward = band_rgamma(self.attr, self.reward_distributions[action,1])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

import numpy as np
import pandas as pd
from scipy.stats import *
import matplotlib.pyplot as plt
import seaborn as sns

rnorm = lambda a, b, n: norm(loc=a,scale=b).rvs(n)
dnorm = lambda a, b: (lambda x:norm(loc=a,scale=b).pdf(x), norm(loc=a,scale=b).mean(), norm(loc=a,scale=b).var())


rgamma = lambda a, b, n: gamma(a=a,scale=1/b).rvs(n)
dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(), gamma(a=a,scale=1/b).var())


rinvgamma = lambda a, b, n: invgamma(a=a,scale=1/b).rvs(n)
dinvgamma = lambda a, b: (lambda x:invgamma(a=a,scale=b).pdf(x), invgamma(a=a,scale=b).mean(), invgamma(a=a,scale=b).var())

class Agent:
    def __init__(self, env,init_a=np.zeros(0),init_b=np.zeros(0)):
        self.env = env
        self.action_space = np.arange(env.action_space.n)
        self.n_trials = env.T + 1
        self.reward_distributions = env.reward_distributions
#TODO choix des parametres initialisation?
        #self.theta = np.zeros(env.action_space.n)
        self.theta = np.ones(env.action_space.n)
        self.action = 0
        self.init_a = init_a
        self.init_b = init_b
        self.a = self.init_a.copy()
        self.b =  self.init_b.copy()
    def reset(self):
        self.a = self.init_a.copy()
        self.b =  self.init_b.copy()
        #self.theta = np.zeros(env.action_space.n)
        self.theta = np.ones(env.action_space.n)
        self.action = 0
    def get_model(self, action):
        pass
class ThompsonSampler(Agent):
    def __init__(self, env, prior,init_a,init_b,model = None,n_mean=1):
        super().__init__(env,init_a,init_b)
        self.prior = prior
        self.n_mean = n_mean
        if model is None:
            self.model = env.model
            self.attr = env.attr
        else:
            self.model = model.name
            self.attr = model.attr
        self.choose_action_ = None
        if self.model == 'bernouilli' and self.prior == 'beta':
            self.update = self.update_berouilli_beta
            self.choose_action_ = lambda a,b : np.random.beta(a,b)
        elif self.model == 'gaussian_mu' and self.prior == 'gaussian':
            self.update = self.update_gaussian_mu_gaussian
            self.choose_action_ = lambda i : rnorm(self.a[i],self.b[i],self.n_mean).mean()
            self.get_model_ = lambda action: dnorm(self.theta[action],self.attr)
            self.get_model_prior_ = lambda action: dnorm(self.a[action],self.b[action])
        elif self.model == 'gaussian_sig' and self.prior == 'invgamma':
            self.update = self.update_gaussian_sig_inv_gamma
            self.choose_action_ = lambda i : rinvgamma(self.a[i],self.b[i],self.n_mean).mean()
            self.get_model_ = lambda action: dnorm(self.attr, self.theta[action])
            self.get_model_prior_ = lambda action: dinvgamma(self.a[action],self.b[action])
        elif self.model == 'gaussian' and self.prior == 'gaussian':
            self.update = self.update_gaussian_gaussian
            self.choose_action_ = lambda a,b : np.random.normal(a,b)
        elif self.model == 'gamma_k' and self.prior == 'gamma':
            self.update = self.update_gamma_k_gamma
            self.choose_action_ = lambda i : rgamma(self.a[i],self.b[i],self.n_mean).mean()
            self.get_model_ = lambda action: dgamma(self.attr, self.theta[action])
            self.get_model_prior_ = lambda action: dgamma(self.a[action],self.b[action])
        else:
            print('not adapted prior!')
            return
    def get_model(self,action):
        return self.get_model_(action)
    
    def get_model_prior(self,action):
        return self.get_model_prior_(action)
        
    def choose_action(self):
        self.theta = np.fromiter(map(self.choose_action_,self.action_space),dtype=np.float)
        self.action = self.action_space[np.argmax(self.theta)]
        return self.action
    
    def update_berouilli_beta(self,state,reward):
        self.a[self.action] += reward
        self.b[self.action] += 1 - reward
        
    def update_gaussian_mu_gaussian(self,state,reward):
        ro = 1 / (self.attr**2 + self.b[self.action]**2)
        self.a[self.action] = ro * (self.attr**2 * self.a[self.action] + self.b[self.action]**2 * reward)
        self.b[self.action] = ro * self.attr**2 * self.b[self.action]**2
        if self.b[self.action] < 10**-2: #avoid inf sig
            self.b[self.action] = 10**-2
        
    def update_gaussian_sig_inv_gamma(self,state,reward):
        self.a[self.action] += 0.5
        self.b[self.action] += 0.5 * (reward - self.attr)**2
    #    self.update = self.update_inv_gamma_inv_gamma
        
    #def update_inv_gamma_inv_gamma(self,state,reward):
    #    self.a[self.action] += self.attr
    #    self.b[self.action] += 1 / reward
        
    def update_gamma_k_gamma(self,state,reward):
        self.a[self.action] += self.attr
        self.b[self.action] += reward


#env = BernouilliBandit([0.1, 0.1, 0.05, 0.01, 0.05, 0.12, 0.015, 0.035, 0.01, 0.11],T=1000)
#rs = RandomSampler(env)
#eg = eGreedy(env)
#ucb = UCB1(env)
#ts = ThompsonSampler(env,prior='beta')
#rews = {'Random':[],
#        'eGreedy':[],
#        'UCB1':[],
#        'Thompson':[]
#        }
env = GaussianMuBandit(np.asarray([[1, 3, 0],
                                       [2, 3, 0.1]]).T
                                      ,T=100)
ts = ThompsonSampler(env,prior='gaussian',n_mean=10,init_a=np.zeros(env.num_bandits),init_b=np.ones(env.num_bandits))
s = env.reset()
ts.reset()
done = False
i = 0
x = np.linspace(-6, 6, num=200)
fig, ax = plt.subplots(3,figsize=(20,10))
for j in range(3):
    ax[j].plot(x,ts.get_model(j)[0](x))
    ax[j].plot(x,ts.get_model_prior(j)[0](x))
    ax[j].plot(x,env.get_model(j)[0](x))
agent = ts
xs = np.linspace(-10,10,200)
def gaussian_render_line():
    source_rews_rs = ColumnDataSource(data={'x':xs,'y':})
    p = figure(tools="", toolbar_location=None,plot_width=800, plot_height=800,title='cum reward')
    p.line(x='x', y='y',source=source_rews_rs, line_width=2,legend='random',color='blue')
    layout_play = column(row(p))
    curdoc().add_root(layout_play)
    def update_rew_rs():
        source_rews_rs.data={'x':np.arange(len(rews['Random'])),'y':np.cumsum(rews['Random'])}
    curdoc().add_periodic_callback(update_rew_rs, 500)

def bernouilli_render(env,agent):
    wins = np.zeros(10)
    looses = np.zeros(10)
    xs = np.linspace(1,10,10)
    
    source_wins = ColumnDataSource(data={'x':xs,'top':wins})
    source_looses = ColumnDataSource(data={'x':xs,'top':looses,'bottom':looses})
    p_play = figure(tools="", toolbar_location=None,plot_width=800, plot_height=400, title="Bernouilli_bandit " + agent.name_agent)
    b_win = p_play.vbar(x='x',width=0.5, bottom=0,
           top='top',source=source_wins, color="green",legend="win")
    b_loose = p_play.vbar(x='x',width=0.5, bottom='bottom',
           top='top',source=source_looses, color="red",legend="loose")
    layout_play = column(row(p_play))
    #
    curdoc().add_root(layout_play)
    
    s = env.reset()
    done = False
    def update_bernouilli_bandits():
        a = agent.choose_action()
        s, r, done, _ = env.step(a)
        rews[agent.name_agent].append(r)
        agent.update(s, r)
        if r == 0:
            looses[a] += 1
        else:
            wins[a] += 1
        source_wins.data = {'x':xs,'top':wins}
        source_looses.data = {'x':xs,'bottom':wins,'top':wins+looses}
    #button.on_click(update)
    #
    ## create a layout for everything
    #layout = column(button, input, output)
    
    # add the layout to curdoc
    #curdoc().add_root(layout)
    curdoc().add_periodic_callback(update_bernouilli_bandits, 50)
bernouilli_render(env,ts)
bernouilli_render_line()

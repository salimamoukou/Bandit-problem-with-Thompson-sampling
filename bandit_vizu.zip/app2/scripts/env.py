import numpy as np
import gym
from gym import spaces
from gym.utils import seeding
from scipy.stats import *

band_rnorm = lambda a, b: norm(loc=a,scale=b).rvs(1)
band_dnorm = lambda a, b: (lambda x:norm(loc=a,scale=b).pdf(x),norm(loc=a,scale=b).mean(),norm(loc=a,scale=b).var())

band_rgamma = lambda a, b: gamma(a=a,scale=1/b).rvs(1)
band_dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(),gamma(a=a,scale=1/b).var())

band_rpareto = lambda a, b: pareto(loc=a,b=b).rvs(1)
band_dpareto = lambda a, b: (lambda x:pareto(loc=a,b=b).pdf(x), pareto(loc=a,b=b).mean(), pareto(loc=a,b=b).var())

band_rinvgamma = lambda a, b: invgamma(a=a,scale=1/b).rvs(1)
band_dinvgamma = lambda a, b: (lambda x:invgamma(a=a,scale=b).pdf(x), invgamma(a=a,scale=b).mean(), invgamma(a=a,scale=b).var())

band_rweibull = lambda a, b: weibull_min(c=a,loc=b).rvs(1)
band_dweibull = lambda a, b: (lambda x:weibull_min(c=a,loc=b).pdf(x), weibull_min(c=a,loc=b).mean(), weibull_min(c=a,loc=b).var())

band_rexpon = lambda a,b:expon(scale=1/a).rvs(1)
band_dexpon = lambda a, b: (lambda x:expon(scale=1/a).pdf(x), expon(scale=1/a).mean(), expon(scale=1/a).var())

band_runiform = lambda a:uniform(scale=a).rvs(1)
band_duniform = lambda a, b: (lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())


band_rbern = lambda a:bernoulli(p=a).rvs(1)
band_dbern = lambda a,b:(lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())


band_rbinomial = lambda a,b:binom(p=a,n=b).rvs(1)
band_dbinomial = lambda a,b:(lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())


band_rpoisson = lambda a,b:poisson(mu=a).rvs(1)
band_dpoisson = lambda a,b:(lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())




class ArmedBanditsEnv(gym.Env):
    def __init__(self, reward_distributions, T = 100):
        self.T = T
        self.t = 0
        self.num_bandits = len(reward_distributions[0])
        self.action_space = spaces.Discrete(self.num_bandits)
        self.observation_space = spaces.Discrete(0)
        self.reward_distributions = reward_distributions
        self.model = ''
        self.attr = None
    def get_model(self, action):
        pass

    def step(self, action):
        pass

    def reset(self):
        self.t = 0
        pass

    def _seed(self, seed=None):
        self.np_random, seed = seeding.np_random(seed)
        return [seed]

# discrete

class BernouilliBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'bernouilli'
    def get_model(self,action):
        return self.reward_distribution[0][action]

    def step(self, action):
        reward = band_rbern(self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class BinomialBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'binomial'
        self.attr = int(reward_distributions[1])
    def get_model(self,action):
        return self.reward_distribution[0][action]

    def step(self, action):
        reward = band_rbinomial(self.reward_distributions[0][action],self.attr)
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info
 
class PoissonBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'poisson'
    def get_model(self,action):
        return self.reward_distribution[0][action]

    def step(self, action):
        reward = band_rpoisson(self.reward_distributions[0][action],0)
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info
    
#continue Bandit

class GaussianMuBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gaussian_mu'
        self.attr = reward_distributions[1]
    def get_model(self, action):
        return band_dnorm(self.reward_distributions[0][action], self.attr)

    def step(self, action):
        reward = band_rnorm(self.reward_distributions[0][action], self.attr)
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GaussianSigBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gaussian_sig'
        self.attr = reward_distributions[1]
        
    def get_model(self, action):
        return band_dnorm(self.attr, self.reward_distributions[0][action])

    def step(self, action):
        reward = band_rnorm(self.attr, self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GaussianBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gaussian'

    def get_model(self, action):
        return band_dnorm(self.reward_distributions[0][action], self.reward_distributions[1][action])

    def step(self, action):
        reward = band_rnorm(self.reward_distributions[0][action], self.reward_distributions[1][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class GammaRateBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'gamma_rate'
        self.attr = reward_distributions[1]

    def get_model(self, action):
        return band_dgamma(self.attr, self.reward_distributions[0][action])

    def step(self, action):
        reward = band_rgamma(self.attr, self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class ExpoBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'expon'
    def get_model(self,action):
        return band_dexpon(self.reward_distributions[0][action])

    def step(self, action):
        reward = band_rexpon(self.reward_distributions[0][action],0)
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

class UnifBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'unif'
    def get_model(self,action):
        return band_duniform(self.reward_distributions[0][action])

    def step(self, action):
        reward = band_runiform(self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info
    
class ParetoShapeBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'pareto_shape'
        self.attr = reward_distributions[1]
    def get_model(self,action):
        return band_dpareto(self.attr, self.reward_distributions[0][action])

    def step(self, action):
        reward = band_rpareto(self.attr, self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info
    
class InvGammaRateBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'invgamma_shape'
        self.attr = reward_distributions[1]
    def get_model(self,action):
        return band_dinvgamma(self.attr, self.reward_distributions[0][action])

    def step(self, action):
        reward = band_rinvgamma(self.attr, self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info
   
class WeibullShapeBandit(ArmedBanditsEnv):
    def __init__(self, reward_distributions, T = 100):
        super().__init__(reward_distributions, T)
        self.model = 'Weibull_shape'
        self.attr = reward_distributions[1]
    def get_model(self,action):
        return band_dweibull(self.attr, self.reward_distributions[0][action])

    def step(self, action):
        reward = band_rweibull(self.attr, self.reward_distributions[0][action])
        if self.t == self.T:
            observation, done, info = None, True, dict() # Defaults
        else:
            observation, done, info = None, False, dict()
        self.t += 1
        return observation, reward, done, info

# pandas and numpy for data manipulation
#TODO change limit done
#import pandas as pd
import numpy as np
from functools import partial

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool, 
                          ColumnDataSource, Panel, 
                          FuncTickFormatter, SingleIntervalTicker, LinearAxis,Span)
from bokeh.models.widgets import (TextInput, inputs, CheckboxGroup, RangeSlider, 
                                  Tabs, CheckboxButtonGroup, 
                                  TableColumn, DataTable, Button, RadioButtonGroup, Select, Slider)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.palettes import Viridis3
from bokeh.layouts import gridplot
from scripts.agent import *
from scripts.env import *

#ts_law_choice={
#        'Bernouilli':dbeta,
#        'Binomial':dbeta,
#        'Gaussian':dnorm,
#        'Exponential':dgamma,
#}
rnorm = lambda a, b, n: norm(loc=a,scale=b).rvs(n)
dnorm = lambda a, b: (lambda x:norm(loc=a,scale=b).pdf(x), norm(loc=a,scale=b).mean(), norm(loc=a,scale=b).var())


rgamma = lambda a, b, n: gamma(a=a,scale=1/b).rvs(n)
dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(), gamma(a=a,scale=1/b).var())


rinvgamma = lambda a, b, n: invgamma(a=a,scale=1/b).rvs(n)
dinvgamma = lambda a, b: (lambda x:invgamma(a=a,scale=b).pdf(x), invgamma(a=a,scale=b).mean(), invgamma(a=a,scale=b).var())

rbeta = lambda a, b, n: beta(a=a,b=b).rvs(n)
dbeta = lambda a, b: (lambda x:beta(a=a,b=b).pdf(x), beta(a=a,b=b).mean(), beta(a=a,b=b).var())

rpareto = lambda a, b, n: pareto(loc=a,b=b).rvs(n)
dpareto = lambda a, b: (lambda x:pareto(loc=a,b=b).pdf(x), pareto(loc=a,b=b).mean(), pareto(loc=a,b=b).var())

band_rnorm = lambda a, b: norm(loc=a,scale=b).rvs(1)
band_dnorm = lambda a, b: (lambda x:norm(loc=a,scale=b).pdf(x),norm(loc=a,scale=b).mean(),norm(loc=a,scale=b).var())

band_rgamma = lambda a, b: gamma(a=a,scale=1/b).rvs(1)
band_dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(),gamma(a=a,scale=1/b).var())

band_rpareto = lambda a, b: pareto(loc=a,b=b).rvs(1)
band_dpareto = lambda a, b: (lambda x:pareto(loc=a,b=b).pdf(x), pareto(loc=a,b=b).mean(), pareto(loc=a,b=b).var())

band_rinvgamma = lambda a, b: invgamma(a=a,scale=1/b).rvs(1)
band_dinvgamma = lambda a, b: (lambda x:invgamma(a=a,scale=b).pdf(x), invgamma(a=a,scale=b).mean(), invgamma(a=a,scale=b).var())

band_rweibull = lambda a, b: weibull_min(c=a,loc=b).rvs(1)
band_dweibull = lambda a, b: (lambda x:weibull_min(c=a,loc=b).pdf(x), weibull_min(c=a,loc=b).mean(), weibull_min(c=a,loc=b).var())

band_rexpon = lambda a,b:expon(scale=1/a).rvs(1)
band_dexpon = lambda a, b: (lambda x:expon(scale=1/a).pdf(x), expon(scale=1/a).mean(), expon(scale=1/a).var())

band_runiform = lambda a:uniform(scale=a).rvs(1)
band_duniform = lambda a, b: (lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())


band_rbern = lambda a:bernoulli(p=a).rvs(1)
band_dbern = lambda a,b:(lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())


band_rbinomial = lambda a,b:binom(p=a,n=b).rvs(1)
band_dbinomial = lambda a,b:(lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())


band_rpoisson = lambda a,b:poisson(mu=a).rvs(1)
band_dpoisson = lambda a,b:(lambda x:uniform(scale=a).pdf(x), uniform(scale=a).mean(), uniform(scale=a).var())





dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(), gamma(a=a,scale=1/b).var())
ts_law_choice={
        'gaussian':dnorm,
        'beta':dbeta,
        'gamma':dgamma,
        'invgamma':dinvgamma,
        'pareto':dpareto
}

band_law_estim={
        'Bernouilli':band_dbern,
        'Binomial':band_dbinomial,
        'Poisson':band_dpoisson,
        'Gaussian':band_dnorm,
        'Exponential':band_dexpon,
        'Gamma':band_dgamma,
        'Pareto':band_dpareto,
        'Invgamma':band_dinvgamma,
        'Weilbull':band_dweibull,
        'Uniform':band_runiform
}

band_law_estim_xs={
        'Bernouilli':np.linspace(-10,10,100),
        'Binomial':np.linspace(-10,10,100),
        'Poisson':np.linspace(-10,10,100),
        'Gaussian':np.linspace(-10,10,100),
        'Exponential':np.linspace(0.001,10,100),
        'Gamma':np.linspace(0.001,10,100),
        'Pareto':np.linspace(0.001,10,100),
        'Invgamma':np.linspace(0.001,10,100),
        'Weilbull':np.linspace(0.001,10,100),
        'Uniform':np.linspace(0,10,100)
}


ts_law_choice_xs={
        #'bernouilli':np.linspace(0,1,100),
        #'binomial':np.linspace(0,1,100),
        'gaussian':np.linspace(-10,10,100),
        'beta':np.linspace(0.1,1,100),
        'gamma':np.linspace(0.001,10,100),
        'invgamma':np.linspace(0.001,10,100),
        'pareto':np.linspace(0.001,10,100),
}


def ft_get_location(i):
    llaw = GLOBAL['band_law']
    if llaw == 'Bernouilli':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Binomial':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Poisson':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Gaussian':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Exponential':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Gamma':
        return GLOBAL['band_attr1'][i] * GLOBAL['band_attr2']
    if llaw == 'Pareto':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Ingamma':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Wibull':
        return GLOBAL['band_attr1'][i]
    if llaw == 'Uniform':
        return GLOBAL['band_attr1'][i]


COLORS = ['blue','red','yellow','orange','green','black','purple','pink','olive','orchid']
band_n = ['2','3','4','5','6','7','8','9','10']

band_discrete_law = ['Bernouilli','Binomial','Poisson']
band_continue_law = ['Gaussian','Exponential','Gamma','Pareto','Invgamma','Weilbull','Uniform']
ts_discrete_law = ['Beta','Beta','Gamma']
ts_continue_law = ['Gaussian','Gamma','Gamma','Gamma','Gamma','Invgamma','Pareto']

ts_law_prior={
    'Discrete':{
        'Bernouilli':'beta',
        'Binomial':'beta',
        'Poisson':'gamma',
    },
    'Continue':{
        'Gaussian':'gaussian',
        'Exponential':'gamma',
        'Gamma':'gamma',
        'Pareto':'gamma',
        'Invgamma':'gamma',
        'Weilbull':'invgamma',
        'Uniform':'pareto',
}
}

play_bandit_to_env = {'Bernouilli':BernouilliBandit,
                      'Binomial':BinomialBandit,
                      'Poisson':PoissonBandit,
                      'Gaussian':GaussianMuBandit,
                      'Exponential':ExpoBandit,
                      'Gamma':GammaRateBandit,
                      'Pareto':ParetoShapeBandit,
                      'Invgamma':InvGammaRateBandit,
                      'Weilbull':WeibullShapeBandit,
                      'Uniform':UnifBandit,
                      }

ts_n = ['2','3','4','5','6','7','8','9','10']

GLOBAL ={
    'run':0,
    'compil':0,
    'band_env':None,

    'ts_agent':None,
    'ucb_agent':None,
    'eg_agent':None,
    'r_agent':None,

    'vizu_arms':np.arange(2),
    'vizu_ts_wins':np.zeros(2),
    'vizu_ts_plays':np.zeros(2),


    'n_arms':2,
    'band_law_type':'Discrete',
    'band_law':'Bernouilli',
    'band_attr1':[0.5]*9,
    'band_attr2':0.5,


    #'ts_law':'Bernouilli',
    'ts_law_prior':'beta',

    'ts_attr1':[0.5]*9,
    'ts_attr2':[0.5]*9,

    'p_bar':None
}



def ft_get_page():

    def ft_band_tex_attrs(attr, old, new, attr_i):
        GLOBAL['band_attr1'][attr_i] = float(new)
        GLOBAL['source_choice_span'+str(attr_i)].data={'x':[ft_get_location(attr_i)], 'y':[0]}
        xs = band_law_estim_xs[GLOBAL['band_law']]
        GLOBAL['source_estim'+str(attr_i)].data={'x':xs,'y':band_law_estim[GLOBAL['band_law']](float(new),GLOBAL['band_attr2'])[0](xs)}
    band_tex_attrs = {}
    band_attrs = []
    for i in range(9):
        band_tex_attrs[i] = TextInput(value="0.5", title="Param1 of arm (prior on it):")
        band_tex_attrs[i].on_change("value", partial(ft_band_tex_attrs,attr_i=i))
        band_attrs.append(band_tex_attrs[i])

    def ft_band_tex_attr2(attr, old, new):
        GLOBAL['band_attr2'] = float(new)
        xs = band_law_estim_xs[GLOBAL['band_law']]
        for attr_i in range(9):
            GLOBAL['source_estim'+str(attr_i)].data={'x':xs,'y':band_law_estim[GLOBAL['band_law']](GLOBAL['band_attr1'][attr_i], float(new))[0](xs)}
    band_tex_attr2 = TextInput(value="0.5", title="Param2 for all arms")
    band_tex_attr2.on_change("value", ft_band_tex_attr2)


    def ft_band_bt_law(attr):
        if attr == 0:
            band_l.children[0].children[1] = row([band_slc_discrete])
            ts_l.children[0].children[0] = row([ts_bt_laws['Discrete']['Bernouilli']])
            ts_l.children[0].children[1] = row([ts_bt_laws_prior['Discrete']['Bernouilli']])
            GLOBAL['ts_law_prior'] = 'beta'
            GLOBAL['band_law_type'] = 'Discrete'
            GLOBAL['band_law'] = 'Bernouilli'
            for i in range(9):
                b_estim[i].visible = False
        else:
            band_l.children[0].children[1] = row([band_slc_continue])
            ts_l.children[0].children[0] = row([ts_bt_laws['Continue']['Gaussian']])
            ts_l.children[0].children[1] = row([ts_bt_laws_prior['Continue']['Gaussian']])
            GLOBAL['band_law_type'] = 'Continue'
            GLOBAL['band_law'] = 'Gaussian'
            GLOBAL['ts_law_prior'] = 'gaussian'

            for i in range(9):
                b_estim[i].visible = True
                if i >= GLOBAL['n_arms']:
                    b_estim[i].visible = False


    band_bt_law = RadioButtonGroup(labels=["Discrete", "Continue"], active=0)
    band_bt_law.on_click(ft_band_bt_law)


    def ft_band_slc_law(attr, old, new):
        GLOBAL['band_law'] = new
        ts_l.children[0].children[0] = row([ts_bt_laws[GLOBAL['band_law_type']][new]])
        ts_l.children[0].children[1] = row([ts_bt_laws_prior[GLOBAL['band_law_type']][new]])
        GLOBAL['ts_law_prior'] = ts_law_prior[GLOBAL['band_law_type']][new]
    band_slc_discrete = Select(title="Law:", value=band_discrete_law[0], options=band_discrete_law)
    band_slc_discrete.on_change('value', ft_band_slc_law)

    band_slc_continue = Select(title="Law:", value=band_continue_law[0], options=band_continue_law)
    band_slc_continue.on_change('value', ft_band_slc_law)


    def ft_band_slc_n(attr, old, new):
        GLOBAL['n_arms'] = int(new)
        band_l.children[1].children[0] = row(band_attrs[:int(new)])
        ts_l.children[1].children[0] = row(ts_attrs[:int(new)])
        ts_l.children[2].children[0] = row(ts_attrs2[:int(new)])

        for i in range(9):
            b_choice_span[i].visible = True
            if i >= GLOBAL['n_arms']:
                b_choice_span[i].visible = False

        if GLOBAL['band_law_type'] == 'Continue':
            for i in range(9):
                b_estim[i].visible = True
                if i >= GLOBAL['n_arms']:
                    b_estim[i].visible = False



    band_slc_n = Select(title="number of arms:", value='2', options=band_n)
    band_slc_n.on_change('value', ft_band_slc_n)



    band_l = layout([[row(band_bt_law), row(band_slc_discrete), row(band_slc_n)],
                     [row(band_attrs[:2])],[row(band_tex_attr2)]])

    #band_row = row(children=band_l, title = 'Bandits model')
    band_row = row(band_l)

##################################TS#######################################

    ts_bt_laws = {'Discrete':{}, 'Continue':{}}
    for obj in band_discrete_law:
        ts_bt_laws['Discrete'][obj] = (Button(label=obj, button_type="success"))
    for obj in band_continue_law:
        ts_bt_laws['Continue'][obj] = (Button(label=obj, button_type="success"))


    ts_bt_laws_prior = {'Discrete':{}, 'Continue':{}}
    for i,obj in enumerate(band_discrete_law):
        ts_bt_laws_prior['Discrete'][obj] = (Button(label=ts_discrete_law[i], button_type="success"))
    for i,obj in enumerate(band_continue_law):
        ts_bt_laws_prior['Continue'][obj] = (Button(label=ts_continue_law[i], button_type="success"))

    def ft_ts_tex_attrs(attr, old, new, attr_i):
        GLOBAL['ts_attr1'][attr_i] = float(new)
        xs = ts_law_choice_xs[GLOBAL['ts_law_prior']]
        GLOBAL['source_choice'+str(attr_i)].data={'x':xs,'y':ts_law_choice[GLOBAL['ts_law_prior']](float(new),GLOBAL['ts_attr2'][attr_i])[0](xs)}
    ts_tex_attrs = {}
    ts_attrs = []
    for i in range(9):
        ts_tex_attrs[i] = TextInput(value="0.5", title="init param1 for prior:")
        ts_tex_attrs[i].on_change("value", partial(ft_ts_tex_attrs,attr_i=i))
        ts_attrs.append(ts_tex_attrs[i])

    def ft_ts_tex_attrs2(attr, old, new, attr_i):
        GLOBAL['ts_attr2'][attr_i] = float(new)
        xs = ts_law_choice_xs[GLOBAL['ts_law_prior']]
        GLOBAL['source_choice'+str(attr_i)].data={'x':xs,'y':ts_law_choice[GLOBAL['ts_law_prior']](GLOBAL['ts_attr1'][attr_i],float(new))[0](xs)}

    ts_tex_attrs2 = {}
    ts_attrs2 = []
    for i in range(9):
        ts_tex_attrs2[i] = TextInput(value="0.5", title="init param2 for prior:")
        ts_tex_attrs2[i].on_change("value", partial(ft_ts_tex_attrs2,attr_i=i))
        ts_attrs2.append(ts_tex_attrs2[i])


    ts_l = layout([[row(ts_bt_laws['Discrete']['Bernouilli']), row(ts_bt_laws_prior['Discrete']['Bernouilli'])],
                   [row(ts_attrs[:2])],
                   [row(ts_attrs2[:2])]
                   ])
    ts_row = row(ts_l)
#################################PLAY#########################################
    def ft_play_bt(attr):
        if attr == 0:
            GLOBAL['run']=1
        else:
            GLOBAL['run']=0
            if attr == 2:
                GLOBAL['compil'] = 0

    play_bt = RadioButtonGroup(labels=["PLAY", "STOP", "RESTART"], active=2)
    play_bt.on_click(ft_play_bt)
    play_row = row(play_bt)



#################################VIZU#########################################
    p_bar = figure(tools="", toolbar_location=None,plot_width=400, plot_height=400, title="Reward by arm")
    GLOBAL['source_wins'] = ColumnDataSource(data={'x':GLOBAL['vizu_arms'],'top':GLOBAL['vizu_ts_wins'], 'color':COLORS[:GLOBAL['n_arms']]})
    b_win = p_bar.vbar(x='x',width=0.5, bottom=0,
                       top='top',source=GLOBAL['source_wins'], color='color')

    p_bar_play = figure(tools="", toolbar_location=None,plot_width=400, plot_height=400, title="number play arm")
    GLOBAL['source_plays'] = ColumnDataSource(data={'x':GLOBAL['vizu_arms'],'top':GLOBAL['vizu_ts_plays'], 'color':COLORS[:GLOBAL['n_arms']]})
    b_play = p_bar_play.vbar(x='x',width=0.5, bottom=0,
           top='top',source=GLOBAL['source_plays'], color='color', legend="play")


    p_choice = figure(tools="", toolbar_location=None,plot_width=400, plot_height=400, title="Thomson objectives")
    b_choice = {}
    b_choice_span = {}
    for i in range(9):
        GLOBAL['source_choice'+str(i)] = ColumnDataSource(data={'x':np.zeros(1),'y':np.zeros(1)})
        b_choice[i] = p_choice.line(x='x', y='y',source=GLOBAL['source_choice'+str(i)], line_width=5,legend=str(i),color=COLORS[i])

    for i in range(9):
        GLOBAL['source_choice_span'+str(i)] = ColumnDataSource(data={'x':[ft_get_location(i)], 'y':[0]})
        b_choice_span[i] = p_choice.circle(x='x', y='y',source=GLOBAL['source_choice_span'+str(i)], size=7, legend=str(i), color=COLORS[i])
        if i >= GLOBAL['n_arms']:
            b_choice_span[i].visible = False

    p_estim = figure(tools="", toolbar_location=None,plot_width=400, plot_height=400, title="True density model")
    b_estim = {}
    xs = band_law_estim_xs[GLOBAL['band_law']]
    for i in range(9):
        GLOBAL['source_estim'+str(i)] = ColumnDataSource(data={'x':xs, 'y':band_law_estim[GLOBAL['band_law']](GLOBAL['band_attr1'][i], GLOBAL['band_attr2'])[0](xs)})
        b_estim[i] = p_estim.line(x='x', y='y',source=GLOBAL['source_estim'+str(i)], line_width=3, legend=str(i), color=COLORS[i])
        b_estim[i].visible = False

    p_rew = figure(tools="", toolbar_location=None,plot_width=400, plot_height=400, title="Cumulative  Reward")
    GLOBAL['source_rew_ts'] = ColumnDataSource(data={'x':np.zeros(1),'y':np.zeros(1)})
    GLOBAL['source_rew_r'] = ColumnDataSource(data={'x':np.zeros(1),'y':np.zeros(1)})
    GLOBAL['source_rew_eg'] = ColumnDataSource(data={'x':np.zeros(1),'y':np.zeros(1)})
    GLOBAL['source_rew_ucb'] = ColumnDataSource(data={'x':np.zeros(1),'y':np.zeros(1)})
    b_rew_ts = p_rew.line(x='x', y='y',source=GLOBAL['source_rew_ts'], line_width=2,legend='Thompson',color='purple')
    b_rew_r = p_rew.line(x='x', y='y',source=GLOBAL['source_rew_r'], line_width=2,legend='Random',color='blue')
    b_rew_eg = p_rew.line(x='x', y='y',source=GLOBAL['source_rew_eg'], line_width=2,legend='eGreed',color='green')
    b_rew_ucb = p_rew.line(x='x', y='y',source=GLOBAL['source_rew_ucb'], line_width=2,legend='UCB',color='red')


    vizu_l = layout([[p_bar,p_choice,p_estim],[p_bar_play],[p_rew]])
    vizu_row = row(vizu_l)

#############################################################################
    tab1_layout = layout([[band_row],[ts_row],[play_bt],[vizu_l]])

    return tab1_layout

#############################################################################
def ft_get_run():
    if GLOBAL['run'] == 1 and GLOBAL['compil'] == 1:
        ft_get_vizu()
    elif GLOBAL['run'] == 1 and GLOBAL['compil'] == 0:
        GLOBAL['bandit_env'] = play_bandit_to_env[GLOBAL['band_law']]((GLOBAL['band_attr1'][:GLOBAL['n_arms']],GLOBAL['band_attr2']))
        GLOBAL['bandit_env'].reset()
        GLOBAL['ts_agent'] = ThompsonSampler(GLOBAL['bandit_env'],GLOBAL['ts_law_prior'],GLOBAL['ts_attr1'][:GLOBAL['n_arms']],GLOBAL['ts_attr2'][:GLOBAL['n_arms']])
        #GLOBAL['ts_agent'].reset()
        GLOBAL['vizu_arms'] = np.arange(GLOBAL['n_arms'])
        GLOBAL['vizu_ts_wins'] = np.zeros(GLOBAL['n_arms'])
        GLOBAL['vizu_ts_plays'] = np.zeros(GLOBAL['n_arms'])


        GLOBAL['r_agent'] = RandomSampler(GLOBAL['bandit_env'])
        GLOBAL['eg_agent'] = eGreedy(GLOBAL['bandit_env'],init_a=np.ones(GLOBAL['n_arms']),init_b=np.ones(GLOBAL['n_arms']))
        GLOBAL['ucb_agent'] = UCB1(GLOBAL['bandit_env'],init_a=np.ones(GLOBAL['n_arms']),init_b=np.ones(GLOBAL['n_arms']))
        GLOBAL['rews'] = {'r_agent':[],
        'eg_agent':[],
        'ucb_agent':[],
        'ts_agent':[]
        }

        GLOBAL['compil'] = 1



def ft_get_vizu():
     ac = GLOBAL['ts_agent'].choose_action()
     s, re, done, _ = GLOBAL['bandit_env'].step(ac)
     GLOBAL['ts_agent'].update(s, re)
     GLOBAL['vizu_ts_wins'][ac] += re
     GLOBAL['vizu_ts_plays'][ac] += 1
     GLOBAL['rews']['ts_agent'].append(re)

     for ag in ['eg_agent','ucb_agent','r_agent']:
        ac = GLOBAL[ag].choose_action()
        s, re, done, _ = GLOBAL['bandit_env'].step(ac)
        GLOBAL[ag].update(s, re)
        GLOBAL['rews'][ag].append(re)

     tmp_len = np.arange(len(GLOBAL['rews']['ts_agent']))
     GLOBAL['source_rew_ts'].data={'x':tmp_len,'y':np.cumsum(GLOBAL['rews']['ts_agent'])}
     GLOBAL['source_rew_r'].data={'x':tmp_len,'y':np.cumsum(GLOBAL['rews']['r_agent'])}
     GLOBAL['source_rew_eg'].data={'x':tmp_len,'y':np.cumsum(GLOBAL['rews']['eg_agent'])}
     GLOBAL['source_rew_ucb'].data={'x':tmp_len,'y':np.cumsum(GLOBAL['rews']['ucb_agent'])}

     GLOBAL['source_wins'].data={'x':GLOBAL['vizu_arms'],'top':GLOBAL['vizu_ts_wins'],'color':COLORS[:GLOBAL['n_arms']]}

     GLOBAL['source_plays'].data={'x':GLOBAL['vizu_arms'],'top':GLOBAL['vizu_ts_plays'],'color':COLORS[:GLOBAL['n_arms']]}


     #xs = ts_law_choice_xs[GLOBAL['band_law']]
     xs = ts_law_choice_xs[GLOBAL['ts_law_prior']]
     for i in range(GLOBAL['n_arms']):
         GLOBAL['source_choice'+str(i)].data={'x':xs,'y':GLOBAL['ts_agent'].get_model_prior(i)[0](xs)}

def tab1():
        tab1_layout = ft_get_page()
        tab = Panel(child=tab1_layout, title = 'Bandits')

        return tab

import numpy as np
import pandas as pd
from scipy.stats import *
import matplotlib.pyplot as plt
import seaborn as sns
from scripts.env import *
from scipy.special import gamma as gammaf

rnorm = lambda a, b, n: norm(loc=a,scale=b).rvs(n)
dnorm = lambda a, b: (lambda x:norm(loc=a,scale=b).pdf(x), norm(loc=a,scale=b).mean(), norm(loc=a,scale=b).var())


rgamma = lambda a, b, n: gamma(a=a,scale=1/b).rvs(n)
dgamma = lambda a, b: (lambda x:gamma(a=a,scale=1/b).pdf(x), gamma(a=a,scale=1/b).mean(), gamma(a=a,scale=1/b).var())


rinvgamma = lambda a, b, n: invgamma(a=a,scale=1/b).rvs(n)
dinvgamma = lambda a, b: (lambda x:invgamma(a=a,scale=b).pdf(x), invgamma(a=a,scale=b).mean(), invgamma(a=a,scale=b).var())

rbeta = lambda a, b, n: beta(a=a,b=b).rvs(n)
dbeta = lambda a, b: (lambda x:beta(a=a,b=b).pdf(x), beta(a=a,b=b).mean(), beta(a=a,b=b).var())

rpareto = lambda a, b, n: pareto(loc=a,b=b).rvs(n)
dpareto = lambda a, b: (lambda x:pareto(loc=a,b=b).pdf(x), pareto(loc=a,b=b).mean(), pareto(loc=a,b=b).var())

class Agent:
    def __init__(self, env,init_a=np.zeros(0),init_b=np.zeros(0),init_c=np.zeros(0), init_d=np.zeros(0)):
        self.env = env
        self.action_space = np.arange(env.action_space.n)
        self.theta = np.ones(env.action_space.n)
        self.action = 0
        self.init_a = init_a
        self.init_b = init_b
        self.init_c = init_c
        self.init_d = init_d
        self.a = self.init_a.copy()
        self.b =  self.init_b.copy()
        self.c = self.init_c.copy()
        self.d =  self.init_d.copy()
    def reset(self):
        self.a = self.init_a.copy()
        self.b =  self.init_b.copy()
        self.c = self.init_c.copy()
        self.d =  self.init_d.copy()
        self.theta = np.ones(env.action_space.n)
        self.action = 0
    def get_model(self, action):
        pass

class RandomSampler(Agent):
    def __init__(self, env):
        super().__init__(env)

    def choose_action(self):
        self.action = np.random.choice(self.action_space)
        return self.action

    def update(self, state, reward):
        pass

class eGreedy(Agent):
    def __init__(self, env, init_a,init_b,n_learning=0, e=0.05):
        super().__init__(env,init_a,init_b)
        self.n_learning = n_learning
        self.e = e
        self.i = 0
    def get_model(self,action):
        return theta[action]

    def choose_action(self):
        self.action = np.random.choice(self.action_space) if self.i < self.n_learning else np.argmax(self.theta)
        self.action = np.random.choice(self.action_space) if np.random.rand() > 1 - self.e else self.action
        return self.action

    def update(self,state,reward):
        self.a[self.action] += reward
        self.b[self.action] += 1
        self.theta = self.a/self.b
        self.i += 1

class UCB1(Agent):
    def __init__(self,env,init_a,init_b):
        super().__init__(env,init_a,init_b)
        self.i = 1

    def choose_action(self):
        self.action = np.argmax(self.theta)
        return self.action

    def get_model(self,action):
        return theta[action]

    def update(self, state, reward):
        self.a[self.action] += reward
        self.b[self.action] += 1
        self.theta = self.a/self.b + np.sqrt(2 * np.log(self.i)/self.b)
        self.i += 1

class ThompsonSampler(Agent):
    def __init__(self, env, prior,init_a,init_b,init_c=np.zeros(0),init_d=np.zeros(0),model = None,n_mean=1):
        super().__init__(env,init_a,init_b,init_c,init_d)
        self.prior = prior
        self.n_mean = n_mean
        if model is None:
            self.model = env.model
            self.attr = env.attr
        else:
            self.model = model.name
            self.attr = model.attr
        self.choose_action_ = None
        if self.model == 'bernouilli' and self.prior == 'beta':
            self.update = self.update_berouilli_beta
            self.choose_action_ = lambda action : rbeta(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dbeta(self.a[action],self.b[action])[1]
            self.get_model_prior_ = lambda action: dbeta(self.a[action],self.b[action])
        elif self.model == 'binomial' and self.prior == 'beta':
            self.update = self.update_binomial_beta
            self.choose_action_ = lambda action : rbeta(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dbeta(self.a[action],self.b[action])[1]
            self.get_model_prior_ = lambda action: dbeta(self.a[action],self.b[action])
        elif self.model == 'poisson' and self.prior == 'gamma':
            self.update = self.update_poisson_gamma
            self.choose_action_ = lambda action : rgamma(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dgamma(self.attr, dgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dgamma(self.a[action],self.b[action])
        elif self.model == 'gaussian_mu' and self.prior == 'gaussian':
            self.update = self.update_gaussian_mu_gaussian
            self.choose_action_ = lambda action : rnorm(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dnorm(dnorm(self.a[action],self.b[action])[1],self.attr)
            self.get_model_prior_ = lambda action: dnorm(self.a[action],self.b[action])
        elif self.model == 'gaussian_sig' and self.prior == 'invgamma':
            self.update = self.update_gaussian_sig_inv_gamma
            self.choose_action_ = lambda action : rinvgamma(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dnorm(self.attr, dinvgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dinvgamma(self.a[action],self.b[action])
        elif self.model == 'gaussian' and self.prior == 'gaussian_gamma':
            self.update = self.update_gaussian_gaussian_gamma
            def f_tmp(action):
                self.c[self.c<=0] = 0.1
                self.d[self.d<=0] = 0.1
                tmp_1 = rgamma(self.c[action],self.d[action],self.n_mean).mean()
                tmp_2 = rnorm(self.a[action],self.b[action] * tmp_1,self.n_mean).mean()
                return tmp_2
            self.choose_action_ = f_tmp
        elif self.model == 'gamma_rate' and self.prior == 'gamma':
            self.update = self.update_gamma_rate_gamma
            self.choose_action_ = lambda action : 1/rgamma(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dgamma(self.attr, dgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dgamma(self.a[action],self.b[action])
        elif self.model == 'expon' and self.prior == 'gamma':
            self.update = self.update_expon_gamma
            self.choose_action_ = lambda action : 1/rgamma(self.a[action],self.b[action],self.n_mean).mean()
            self.get_model_ = lambda action: dgamma(self.attr, dgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dgamma(self.a[action],self.b[action])
        elif self.model == 'unif' and self.prior == 'pareto':
            self.update = self.update_unif_pareto
            self.choose_action_ = lambda action : 0.5*rpareto(self.a[action],self.b[action],self.n_mean).mean()
            #self.get_model_ = lambda action: dpareto(self.attr, dgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dpareto(self.a[action],self.b[action])
        elif self.model == 'pareto_shape' and self.prior == 'gamma':
            self.update = self.update_pareto_shape_gamma
            def f_tmp(action):
                tmp_ = rgamma(self.a[action],self.b[action],self.n_mean).mean()
                #if (tmp_ < 1).any():
                #    print('error: shape inf a 1')
                return tmp_ * self.attr / (tmp_ - 1)
            self.choose_action_ = f_tmp
            #self.get_model_ = lambda action: dgamma(self.attr, dgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dgamma(self.a[action],self.b[action])
        elif self.model == 'invgamma_shape' and self.prior == 'gamma':
            self.update = self.update_invgamma_shape_gamma
            self.choose_action_ = lambda action : self.attr/(1 - rgamma(self.a[action],self.b[action],self.n_mean).mean())
            self.get_model_ = lambda action: dgamma(self.attr, dgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dgamma(self.a[action],self.b[action])
        elif self.model == 'Weibull_shape' and self.prior == 'invgamma':
            self.update = self.update_Weibull_shape_gamma
            self.choose_action_ = lambda action : 1/rinvgamma(self.a[action],self.b[action],self.n_mean).mean() * gammaf(1 + 1/self.attr)
            self.get_model_ = lambda action: dinvgamma(self.attr, dinvgamma(self.a[action],self.b[action])[1])
            self.get_model_prior_ = lambda action: dinvgamma(self.a[action],self.b[action])

        else:
            print('not adapted prior!')
            print(self.model)
            print(self.prior)
            return
    def get_model(self,action):
        return self.get_model_(action)

    def get_model_prior(self,action):
        return self.get_model_prior_(action)

    def choose_action(self):
        self.theta = np.fromiter(map(self.choose_action_,self.action_space),dtype=np.float)
        self.action = self.action_space[np.argmax(self.theta)]
        return self.action
   #discrete
    def update_berouilli_beta(self,state,reward):
        self.a[self.action] += reward
        self.b[self.action] += 1 - reward

    def update_binomial_beta(self,state,reward):
        self.a[self.action] += reward
        self.b[self.action] += self.attr - reward

    def update_poisson_gamma(self,state,reward):
        self.a[self.action] += reward
        self.b[self.action] += 1
    #continue

    def update_gaussian_mu_gaussian(self,state,reward):
        ro = 1 / (self.attr**2 + self.b[self.action]**2)
        self.a[self.action] = ro * (self.attr**2 * self.a[self.action] + self.b[self.action]**2 * reward)
        self.b[self.action] = ro * self.attr**2 * self.b[self.action]**2
        if self.b[self.action] < 10**-2: #avoid inf sig
            self.b[self.action] = 10**-2

    def update_gaussian_sig_inv_gamma(self,state,reward):
        self.a[self.action] += 0.5
        self.b[self.action] += 0.5 * (reward - self.attr)**2

    def update_gamma_rate_gamma(self,state,reward):
        self.a[self.action] += self.attr
        self.b[self.action] += reward

    def update_expon_gamma(self,state,reward):
        self.a[self.action] += 1
        self.b[self.action] += reward

    def update_unif_pareto(self,state,reward):
        self.a[self.action] = max(reward, self.a[self.action])
        self.b[self.action] += 1

    def update_pareto_shape_gamma(self,state,reward):
        self.a[self.action] += 1
        self.b[self.action] += np.log(reward/self.attr)

    def update_invgamma_shape_gamma(self, state, reward):
        self.a[self.action] += self.attr
        self.b[self.action] += 1/reward
    def update_Weibull_shape_gamma(self, state, reward):
        self.a[self.action] += 1
        self.b[self.action] += reward**self.attr

    def update_gaussian_gaussian_gamma(self,state,reward):
        self.c[self.action] += 0.5
        self.d[self.action] += 0.5 * self.b[self.action] / (1 + self.b[self.action])*(reward-self.a[self.action])
        to_hat = dgamma(self.c, self.d)[1][self.action]
        self.a[self.action] = reward/ (1+ self.b[self.action]) + self.b[self.action]/(1 + self.b[self.action]) * self.a[self.action]
        self.b[self.action] = to_hat * (1 + self.b[self.action])
